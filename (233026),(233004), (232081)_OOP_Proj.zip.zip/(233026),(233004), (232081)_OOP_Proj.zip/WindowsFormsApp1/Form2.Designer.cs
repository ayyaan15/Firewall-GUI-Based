﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBoxSourceIPAddress = new System.Windows.Forms.TextBox();
            this.textBoxDestinationIPAddress = new System.Windows.Forms.TextBox();
            this.textBoxDestinationPort = new System.Windows.Forms.TextBox();
            this.textBoxProtocol = new System.Windows.Forms.TextBox();
            this.textBoxSourcePort = new System.Windows.Forms.TextBox();
            this.textBoxData = new System.Windows.Forms.TextBox();
            this.labelSourceIPAddress = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelSourcePort = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelProtocol = new System.Windows.Forms.Label();
            this.labelData = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_comboboxRules = new System.Windows.Forms.Label();
            this.label_packet_data = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(766, 347);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(31, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(24, 24);
            this.button1.TabIndex = 1;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.icons8_cancel;
            this.pictureBox1.Location = new System.Drawing.Point(31, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textBoxSourceIPAddress
            // 
            this.textBoxSourceIPAddress.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSourceIPAddress.Location = new System.Drawing.Point(31, 119);
            this.textBoxSourceIPAddress.Multiline = true;
            this.textBoxSourceIPAddress.Name = "textBoxSourceIPAddress";
            this.textBoxSourceIPAddress.Size = new System.Drawing.Size(275, 38);
            this.textBoxSourceIPAddress.TabIndex = 3;
            this.textBoxSourceIPAddress.TextChanged += new System.EventHandler(this.textBoxSourceIPAddress_TextChanged);
            // 
            // textBoxDestinationIPAddress
            // 
            this.textBoxDestinationIPAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDestinationIPAddress.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDestinationIPAddress.Location = new System.Drawing.Point(31, 206);
            this.textBoxDestinationIPAddress.Multiline = true;
            this.textBoxDestinationIPAddress.Name = "textBoxDestinationIPAddress";
            this.textBoxDestinationIPAddress.Size = new System.Drawing.Size(275, 38);
            this.textBoxDestinationIPAddress.TabIndex = 4;
            this.textBoxDestinationIPAddress.TextChanged += new System.EventHandler(this.textBoxDestinationIPAddress_TextChanged);
            // 
            // textBoxDestinationPort
            // 
            this.textBoxDestinationPort.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDestinationPort.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDestinationPort.Location = new System.Drawing.Point(390, 119);
            this.textBoxDestinationPort.Multiline = true;
            this.textBoxDestinationPort.Name = "textBoxDestinationPort";
            this.textBoxDestinationPort.Size = new System.Drawing.Size(275, 38);
            this.textBoxDestinationPort.TabIndex = 5;
            this.textBoxDestinationPort.TextChanged += new System.EventHandler(this.textBoxDestinationPort_TextChanged);
            // 
            // textBoxProtocol
            // 
            this.textBoxProtocol.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxProtocol.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxProtocol.Location = new System.Drawing.Point(390, 206);
            this.textBoxProtocol.Multiline = true;
            this.textBoxProtocol.Name = "textBoxProtocol";
            this.textBoxProtocol.Size = new System.Drawing.Size(275, 38);
            this.textBoxProtocol.TabIndex = 6;
            this.textBoxProtocol.TextChanged += new System.EventHandler(this.textBoxProtocol_TextChanged);
            // 
            // textBoxSourcePort
            // 
            this.textBoxSourcePort.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxSourcePort.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSourcePort.Location = new System.Drawing.Point(31, 287);
            this.textBoxSourcePort.Multiline = true;
            this.textBoxSourcePort.Name = "textBoxSourcePort";
            this.textBoxSourcePort.Size = new System.Drawing.Size(275, 38);
            this.textBoxSourcePort.TabIndex = 7;
            this.textBoxSourcePort.TextChanged += new System.EventHandler(this.textBoxSourcePort_TextChanged);
            // 
            // textBoxData
            // 
            this.textBoxData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxData.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxData.Location = new System.Drawing.Point(390, 287);
            this.textBoxData.Multiline = true;
            this.textBoxData.Name = "textBoxData";
            this.textBoxData.Size = new System.Drawing.Size(275, 38);
            this.textBoxData.TabIndex = 8;
            this.textBoxData.TextChanged += new System.EventHandler(this.textBoxData_TextChanged);
            // 
            // labelSourceIPAddress
            // 
            this.labelSourceIPAddress.AutoSize = true;
            this.labelSourceIPAddress.BackColor = System.Drawing.SystemColors.Control;
            this.labelSourceIPAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelSourceIPAddress.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSourceIPAddress.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelSourceIPAddress.Location = new System.Drawing.Point(27, 95);
            this.labelSourceIPAddress.Name = "labelSourceIPAddress";
            this.labelSourceIPAddress.Size = new System.Drawing.Size(202, 21);
            this.labelSourceIPAddress.TabIndex = 9;
            this.labelSourceIPAddress.Text = " Enter | Source IP Address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(27, 182);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 21);
            this.label1.TabIndex = 15;
            this.label1.Text = " Enter | Destination IP Address";
            // 
            // labelSourcePort
            // 
            this.labelSourcePort.AutoSize = true;
            this.labelSourcePort.BackColor = System.Drawing.SystemColors.Control;
            this.labelSourcePort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelSourcePort.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSourcePort.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelSourcePort.Location = new System.Drawing.Point(27, 263);
            this.labelSourcePort.Name = "labelSourcePort";
            this.labelSourcePort.Size = new System.Drawing.Size(151, 21);
            this.labelSourcePort.TabIndex = 16;
            this.labelSourcePort.Text = "Enter | Source Port";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(386, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(188, 21);
            this.label3.TabIndex = 17;
            this.label3.Text = "Enter | Destination Port";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // labelProtocol
            // 
            this.labelProtocol.AutoSize = true;
            this.labelProtocol.BackColor = System.Drawing.SystemColors.Control;
            this.labelProtocol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelProtocol.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProtocol.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelProtocol.Location = new System.Drawing.Point(386, 182);
            this.labelProtocol.Name = "labelProtocol";
            this.labelProtocol.Size = new System.Drawing.Size(132, 21);
            this.labelProtocol.TabIndex = 18;
            this.labelProtocol.Text = " Enter | Protocol";
            // 
            // labelData
            // 
            this.labelData.AutoSize = true;
            this.labelData.BackColor = System.Drawing.SystemColors.Control;
            this.labelData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelData.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelData.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelData.Location = new System.Drawing.Point(386, 263);
            this.labelData.Name = "labelData";
            this.labelData.Size = new System.Drawing.Size(99, 21);
            this.labelData.TabIndex = 19;
            this.labelData.Text = "Enter | Data";
            this.labelData.Click += new System.EventHandler(this.label5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button2.Location = new System.Drawing.Point(592, 362);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(186, 43);
            this.button2.TabIndex = 20;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Allow",
            "Deny"});
            this.comboBox1.Location = new System.Drawing.Point(210, 365);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(275, 28);
            this.comboBox1.TabIndex = 21;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label_comboboxRules
            // 
            this.label_comboboxRules.AutoSize = true;
            this.label_comboboxRules.BackColor = System.Drawing.SystemColors.Control;
            this.label_comboboxRules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_comboboxRules.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_comboboxRules.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label_comboboxRules.Location = new System.Drawing.Point(207, 341);
            this.label_comboboxRules.Name = "label_comboboxRules";
            this.label_comboboxRules.Size = new System.Drawing.Size(118, 21);
            this.label_comboboxRules.TabIndex = 22;
            this.label_comboboxRules.Text = "Please | Select";
            // 
            // label_packet_data
            // 
            this.label_packet_data.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_packet_data.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label_packet_data.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_packet_data.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_packet_data.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label_packet_data.Location = new System.Drawing.Point(0, 412);
            this.label_packet_data.Name = "label_packet_data";
            this.label_packet_data.Size = new System.Drawing.Size(790, 118);
            this.label_packet_data.TabIndex = 30;
            this.label_packet_data.Text = resources.GetString("label_packet_data.Text");
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(790, 530);
            this.Controls.Add(this.label_packet_data);
            this.Controls.Add(this.label_comboboxRules);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.labelData);
            this.Controls.Add(this.labelProtocol);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelSourcePort);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelSourceIPAddress);
            this.Controls.Add(this.textBoxData);
            this.Controls.Add(this.textBoxSourcePort);
            this.Controls.Add(this.textBoxProtocol);
            this.Controls.Add(this.textBoxDestinationPort);
            this.Controls.Add(this.textBoxDestinationIPAddress);
            this.Controls.Add(this.textBoxSourceIPAddress);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.Text = "Rules";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBoxSourceIPAddress;
        private System.Windows.Forms.TextBox textBoxDestinationIPAddress;
        private System.Windows.Forms.TextBox textBoxDestinationPort;
        private System.Windows.Forms.TextBox textBoxProtocol;
        private System.Windows.Forms.TextBox textBoxSourcePort;
        private System.Windows.Forms.TextBox textBoxData;
        private System.Windows.Forms.Label labelSourceIPAddress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelSourcePort;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelProtocol;
        private System.Windows.Forms.Label labelData;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label_comboboxRules;
        private System.Windows.Forms.Label label_packet_data;
    }
}