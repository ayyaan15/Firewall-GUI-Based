﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormsApp1.Form4;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        private List<Rule> rules;
     
        //static data member for counting of the rule
        private static int ruleCounter = 1;

      
       
        public Form2(List<Rule> rules)
        {
            InitializeComponent();
            this.rules = rules;
        }
     
        public class Rule
        {
            public int RuleNumber { get; set; }
            public string Source_IPAddress { get; set; }
            public string Destination_IPAddress { get; set; }
            public int Source_Port { get; set; }
            public int Destination_Port { get; set; }
            public string Protocol { get; set; }
            public string Data { get; set; }
            public string Action { get; set; }

            public bool IsIPMatchPublic(string ip1, string ip2)
            {
                return IsIPMatch(ip1, ip2);
            }
            public bool IsMatch(Form4.Packet packet)
            {
                return IsIPMatch(Source_IPAddress, packet.Source_IPAddress) &&
                       IsIPMatch(Destination_IPAddress, packet.Destination_IPAddress) &&
                       Source_Port == packet.Source_Port &&
                       Destination_Port == packet.Destination_Port &&
                       Protocol.Equals(packet.Protocol, StringComparison.OrdinalIgnoreCase) &&
                       (Data == null || Data.Equals(packet.Data, StringComparison.OrdinalIgnoreCase));
            }

            private bool IsIPMatch(string ruleIP, string packetIP)
            {
                if (ruleIP.Contains('/'))
                {
                    return IsIPInRange(ruleIP, packetIP);
                }
                return ruleIP == packetIP;
            }

            private bool IsIPInRange(string cidr, string ip)
            {
                string[] parts = cidr.Split('/');
                if (parts.Length != 2) return false;

                if (!IPAddress.TryParse(parts[0], out IPAddress cidrAddress)) return false;
                if (!int.TryParse(parts[1], out int prefixLength)) return false;
                if (!IPAddress.TryParse(ip, out IPAddress ipAddress)) return false;

                byte[] ipBytes = ipAddress.GetAddressBytes();
                byte[] cidrBytes = cidrAddress.GetAddressBytes();

                int bytesToCheck = prefixLength / 8;
                int bitsToCheck = prefixLength % 8;

                for (int i = 0; i < bytesToCheck; i++)
                {
                    if (ipBytes[i] != cidrBytes[i])
                    {
                        return false;
                    }
                }

                if (bitsToCheck > 0)
                {
                    int mask = 0xFF00 >> bitsToCheck;
                    if ((ipBytes[bytesToCheck] & mask) != (cidrBytes[bytesToCheck] & mask))
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // this will close the Rules form 
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if the mandatory fields (IP addresses, ports, and protocol) are filled
            if (!string.IsNullOrWhiteSpace(textBoxSourceIPAddress.Text) &&
                !string.IsNullOrWhiteSpace(textBoxDestinationIPAddress.Text) &&
                !string.IsNullOrWhiteSpace(textBoxProtocol.Text) &&
                int.TryParse(textBoxSourcePort.Text, out int sourcePort) &&
                int.TryParse(textBoxDestinationPort.Text, out int destinationPort) &&
                    comboBox1.SelectedItem != null)
            {
                // Validate IP addresses or ranges
                if (IsValidIPAddressOrRange(textBoxSourceIPAddress.Text) &&
                    IsValidIPAddressOrRange(textBoxDestinationIPAddress.Text))
                {
                    // Validate port numbers
                    if (IsValidPort(sourcePort) && IsValidPort(destinationPort))
                    {
                        // Create a new rule
                        Rule rule = new Rule
                        {
                            RuleNumber = ruleCounter++,
                            Source_IPAddress = textBoxSourceIPAddress.Text,
                            Destination_IPAddress = textBoxDestinationIPAddress.Text,
                            Source_Port = sourcePort,
                            Destination_Port = destinationPort,
                            Protocol = textBoxProtocol.Text,
                            Data = textBoxData.Text,
                            Action = comboBox1.SelectedItem.ToString()
                        };

                        // Add the rule to the list
                        rules.Add(rule);

                        // Clear the text boxes
                        ClearFormFields();

                        // Show a success message
                        MessageBox.Show("Rule saved successfully!", "Success",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Please enter valid port numbers (1-65535).", "Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter valid IP addresses or ranges (e.g., 192.168.0.1 or 192.168.0.1/24).", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Show an error message if mandatory fields are not filled
                MessageBox.Show("Please enter valid data for IP addresses, ports, and protocol.", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

       

    // Method to validate IP address or range format
    private bool IsValidIPAddressOrRange(string ipAddressOrRange)
        {
            if (ipAddressOrRange.Contains('/'))
            {
                return IsValidIPRange(ipAddressOrRange);
            }
            return IsValidIPAddress(ipAddressOrRange);
        }

        // Method to validate IP address format
        private bool IsValidIPAddress(string ipAddress)
        {
            return IPAddress.TryParse(ipAddress, out _);
        }

        private bool IsValidPort(int port)
        {
            return port >= 1 && port <= 65535;
        }

        

        // Method to validate IP address range format
        private bool IsValidIPRange(string ipRange)
        {
            string[] parts = ipRange.Split('/');
            if (parts.Length != 2) return false;

            if (!IsValidIPAddress(parts[0])) return false;
            if (!int.TryParse(parts[1], out int subnet)) return false;

            return subnet >= 0 && subnet <= 32;
        }

        private void ClearFormFields()
        {
            textBoxSourceIPAddress.Clear();
            textBoxDestinationIPAddress.Clear();
            textBoxSourcePort.Clear();
            textBoxDestinationPort.Clear();
            textBoxProtocol.Clear();
            textBoxData.Clear();
            comboBox1.SelectedIndex = -1;
        }



        private void textBoxSourceIPAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxDestinationPort_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxDestinationIPAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxProtocol_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxSourcePort_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxData_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
      

    }

}


