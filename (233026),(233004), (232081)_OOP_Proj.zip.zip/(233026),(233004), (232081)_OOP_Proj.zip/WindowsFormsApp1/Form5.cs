﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        private List<Form2.Rule> rules;


        public Form5(List<Form2.Rule> rules)
        {
            InitializeComponent();
            this.rules = rules;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // this will close the check packet form 
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            LoadRulesIntoDataGridView();

        }
        private void LoadRulesIntoDataGridView()
        {
            // Assuming you have a DataGridView named dataGridView1
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = rules;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        

        

        private void text_Box_checkPacket_displayresult_TextChanged(object sender, EventArgs e)
        {

        }

        private void iconButtonViewRules_Click(object sender, EventArgs e)
        {   // when the the iconbuttonview rules is clikced the rules are shown 
            LoadRulesIntoDataGridView();
        }
    }
}
