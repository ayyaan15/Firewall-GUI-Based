﻿namespace WindowsFormsApp1
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelPacketSourceIPAddress = new System.Windows.Forms.Label();
            this.text_Box_Packet_Source_IP_Address = new System.Windows.Forms.TextBox();
            this.labelPacketDestinationPort = new System.Windows.Forms.Label();
            this.text_Box_Packet_Destination_Port = new System.Windows.Forms.TextBox();
            this.labelPacketDestinationIPAddress = new System.Windows.Forms.Label();
            this.text_Box_Packet_Destination_IP_Address = new System.Windows.Forms.TextBox();
            this.labelPacketSourcePort = new System.Windows.Forms.Label();
            this.text_Box_Packet_Source_Port = new System.Windows.Forms.TextBox();
            this.labelPacketProtocol = new System.Windows.Forms.Label();
            this.text_Box_Packet_Protocol = new System.Windows.Forms.TextBox();
            this.labelPacketData = new System.Windows.Forms.Label();
            this.button_Packet_clear = new System.Windows.Forms.Button();
            this.text_Box_Packet_Data = new System.Windows.Forms.TextBox();
            this.label_packet_data = new System.Windows.Forms.Label();
            this.button_Check_packet = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(766, 330);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.icons8_cancel;
            this.pictureBox1.Location = new System.Drawing.Point(36, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // labelPacketSourceIPAddress
            // 
            this.labelPacketSourceIPAddress.AutoSize = true;
            this.labelPacketSourceIPAddress.BackColor = System.Drawing.SystemColors.Control;
            this.labelPacketSourceIPAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPacketSourceIPAddress.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPacketSourceIPAddress.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelPacketSourceIPAddress.Location = new System.Drawing.Point(32, 91);
            this.labelPacketSourceIPAddress.Name = "labelPacketSourceIPAddress";
            this.labelPacketSourceIPAddress.Size = new System.Drawing.Size(257, 21);
            this.labelPacketSourceIPAddress.TabIndex = 10;
            this.labelPacketSourceIPAddress.Text = " Enter | Packet Source IP Address";
            // 
            // text_Box_Packet_Source_IP_Address
            // 
            this.text_Box_Packet_Source_IP_Address.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Box_Packet_Source_IP_Address.Location = new System.Drawing.Point(25, 115);
            this.text_Box_Packet_Source_IP_Address.Multiline = true;
            this.text_Box_Packet_Source_IP_Address.Name = "text_Box_Packet_Source_IP_Address";
            this.text_Box_Packet_Source_IP_Address.Size = new System.Drawing.Size(275, 38);
            this.text_Box_Packet_Source_IP_Address.TabIndex = 11;
            this.text_Box_Packet_Source_IP_Address.TextChanged += new System.EventHandler(this.textBoxSourceIPAddress_TextChanged);
            // 
            // labelPacketDestinationPort
            // 
            this.labelPacketDestinationPort.AutoSize = true;
            this.labelPacketDestinationPort.BackColor = System.Drawing.SystemColors.Control;
            this.labelPacketDestinationPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPacketDestinationPort.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPacketDestinationPort.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelPacketDestinationPort.Location = new System.Drawing.Point(409, 91);
            this.labelPacketDestinationPort.Name = "labelPacketDestinationPort";
            this.labelPacketDestinationPort.Size = new System.Drawing.Size(243, 21);
            this.labelPacketDestinationPort.TabIndex = 18;
            this.labelPacketDestinationPort.Text = "Enter | Packet Destination Port";
            this.labelPacketDestinationPort.Click += new System.EventHandler(this.label3_Click);
            // 
            // text_Box_Packet_Destination_Port
            // 
            this.text_Box_Packet_Destination_Port.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Box_Packet_Destination_Port.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Box_Packet_Destination_Port.Location = new System.Drawing.Point(395, 115);
            this.text_Box_Packet_Destination_Port.Multiline = true;
            this.text_Box_Packet_Destination_Port.Name = "text_Box_Packet_Destination_Port";
            this.text_Box_Packet_Destination_Port.Size = new System.Drawing.Size(275, 38);
            this.text_Box_Packet_Destination_Port.TabIndex = 19;
            this.text_Box_Packet_Destination_Port.TextChanged += new System.EventHandler(this.textBoxDestinationPort_TextChanged);
            // 
            // labelPacketDestinationIPAddress
            // 
            this.labelPacketDestinationIPAddress.AutoSize = true;
            this.labelPacketDestinationIPAddress.BackColor = System.Drawing.SystemColors.Control;
            this.labelPacketDestinationIPAddress.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPacketDestinationIPAddress.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPacketDestinationIPAddress.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelPacketDestinationIPAddress.Location = new System.Drawing.Point(21, 198);
            this.labelPacketDestinationIPAddress.Name = "labelPacketDestinationIPAddress";
            this.labelPacketDestinationIPAddress.Size = new System.Drawing.Size(290, 21);
            this.labelPacketDestinationIPAddress.TabIndex = 20;
            this.labelPacketDestinationIPAddress.Text = " Enter| Packet Destination IP Address";
            this.labelPacketDestinationIPAddress.Click += new System.EventHandler(this.label1_Click);
            // 
            // text_Box_Packet_Destination_IP_Address
            // 
            this.text_Box_Packet_Destination_IP_Address.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Box_Packet_Destination_IP_Address.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Box_Packet_Destination_IP_Address.Location = new System.Drawing.Point(25, 222);
            this.text_Box_Packet_Destination_IP_Address.Multiline = true;
            this.text_Box_Packet_Destination_IP_Address.Name = "text_Box_Packet_Destination_IP_Address";
            this.text_Box_Packet_Destination_IP_Address.Size = new System.Drawing.Size(275, 38);
            this.text_Box_Packet_Destination_IP_Address.TabIndex = 21;
            this.text_Box_Packet_Destination_IP_Address.TextChanged += new System.EventHandler(this.textBoxDestinationIPAddress_TextChanged);
            // 
            // labelPacketSourcePort
            // 
            this.labelPacketSourcePort.AutoSize = true;
            this.labelPacketSourcePort.BackColor = System.Drawing.SystemColors.Control;
            this.labelPacketSourcePort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPacketSourcePort.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPacketSourcePort.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelPacketSourcePort.Location = new System.Drawing.Point(21, 274);
            this.labelPacketSourcePort.Name = "labelPacketSourcePort";
            this.labelPacketSourcePort.Size = new System.Drawing.Size(206, 21);
            this.labelPacketSourcePort.TabIndex = 22;
            this.labelPacketSourcePort.Text = "Enter | Packet Source Port";
            this.labelPacketSourcePort.Click += new System.EventHandler(this.labelSourcePort_Click);
            // 
            // text_Box_Packet_Source_Port
            // 
            this.text_Box_Packet_Source_Port.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Box_Packet_Source_Port.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Box_Packet_Source_Port.Location = new System.Drawing.Point(25, 298);
            this.text_Box_Packet_Source_Port.Multiline = true;
            this.text_Box_Packet_Source_Port.Name = "text_Box_Packet_Source_Port";
            this.text_Box_Packet_Source_Port.Size = new System.Drawing.Size(275, 38);
            this.text_Box_Packet_Source_Port.TabIndex = 23;
            this.text_Box_Packet_Source_Port.TextChanged += new System.EventHandler(this.textBoxSourcePort_TextChanged);
            // 
            // labelPacketProtocol
            // 
            this.labelPacketProtocol.AutoSize = true;
            this.labelPacketProtocol.BackColor = System.Drawing.SystemColors.Control;
            this.labelPacketProtocol.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPacketProtocol.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPacketProtocol.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelPacketProtocol.Location = new System.Drawing.Point(409, 198);
            this.labelPacketProtocol.Name = "labelPacketProtocol";
            this.labelPacketProtocol.Size = new System.Drawing.Size(187, 21);
            this.labelPacketProtocol.TabIndex = 24;
            this.labelPacketProtocol.Text = " Enter | Packet Protocol";
            this.labelPacketProtocol.Click += new System.EventHandler(this.labelProtocol_Click);
            // 
            // text_Box_Packet_Protocol
            // 
            this.text_Box_Packet_Protocol.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Box_Packet_Protocol.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Box_Packet_Protocol.Location = new System.Drawing.Point(395, 222);
            this.text_Box_Packet_Protocol.Multiline = true;
            this.text_Box_Packet_Protocol.Name = "text_Box_Packet_Protocol";
            this.text_Box_Packet_Protocol.Size = new System.Drawing.Size(275, 38);
            this.text_Box_Packet_Protocol.TabIndex = 25;
            this.text_Box_Packet_Protocol.TextChanged += new System.EventHandler(this.textBoxProtocol_TextChanged);
            // 
            // labelPacketData
            // 
            this.labelPacketData.AutoSize = true;
            this.labelPacketData.BackColor = System.Drawing.SystemColors.Control;
            this.labelPacketData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.labelPacketData.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPacketData.ForeColor = System.Drawing.SystemColors.GrayText;
            this.labelPacketData.Location = new System.Drawing.Point(409, 274);
            this.labelPacketData.Name = "labelPacketData";
            this.labelPacketData.Size = new System.Drawing.Size(158, 21);
            this.labelPacketData.TabIndex = 26;
            this.labelPacketData.Text = "Enter |  Packet Data";
            // 
            // button_Packet_clear
            // 
            this.button_Packet_clear.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Packet_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Packet_clear.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Packet_clear.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button_Packet_clear.Location = new System.Drawing.Point(592, 358);
            this.button_Packet_clear.Name = "button_Packet_clear";
            this.button_Packet_clear.Size = new System.Drawing.Size(186, 43);
            this.button_Packet_clear.TabIndex = 28;
            this.button_Packet_clear.Text = "Clear | Boxes";
            this.button_Packet_clear.UseVisualStyleBackColor = false;
            this.button_Packet_clear.Click += new System.EventHandler(this.button_Packet_save_Click);
            // 
            // text_Box_Packet_Data
            // 
            this.text_Box_Packet_Data.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Box_Packet_Data.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Box_Packet_Data.Location = new System.Drawing.Point(395, 298);
            this.text_Box_Packet_Data.Multiline = true;
            this.text_Box_Packet_Data.Name = "text_Box_Packet_Data";
            this.text_Box_Packet_Data.Size = new System.Drawing.Size(275, 38);
            this.text_Box_Packet_Data.TabIndex = 27;
            this.text_Box_Packet_Data.TextChanged += new System.EventHandler(this.textBoxData_TextChanged);
            // 
            // label_packet_data
            // 
            this.label_packet_data.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label_packet_data.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label_packet_data.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label_packet_data.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_packet_data.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label_packet_data.Location = new System.Drawing.Point(0, 404);
            this.label_packet_data.Name = "label_packet_data";
            this.label_packet_data.Size = new System.Drawing.Size(790, 126);
            this.label_packet_data.TabIndex = 29;
            this.label_packet_data.Text = resources.GetString("label_packet_data.Text");
            this.label_packet_data.Click += new System.EventHandler(this.label_packet_data_Click);
            // 
            // button_Check_packet
            // 
            this.button_Check_packet.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Check_packet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_Check_packet.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Check_packet.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button_Check_packet.Location = new System.Drawing.Point(245, 358);
            this.button_Check_packet.Name = "button_Check_packet";
            this.button_Check_packet.Size = new System.Drawing.Size(212, 46);
            this.button_Check_packet.TabIndex = 30;
            this.button_Check_packet.Text = "Check | Packet";
            this.button_Check_packet.UseVisualStyleBackColor = false;
            this.button_Check_packet.Click += new System.EventHandler(this.button_Check_packet_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 530);
            this.Controls.Add(this.button_Check_packet);
            this.Controls.Add(this.label_packet_data);
            this.Controls.Add(this.button_Packet_clear);
            this.Controls.Add(this.text_Box_Packet_Data);
            this.Controls.Add(this.labelPacketData);
            this.Controls.Add(this.text_Box_Packet_Protocol);
            this.Controls.Add(this.labelPacketProtocol);
            this.Controls.Add(this.text_Box_Packet_Source_Port);
            this.Controls.Add(this.labelPacketSourcePort);
            this.Controls.Add(this.text_Box_Packet_Destination_IP_Address);
            this.Controls.Add(this.labelPacketDestinationIPAddress);
            this.Controls.Add(this.text_Box_Packet_Destination_Port);
            this.Controls.Add(this.labelPacketDestinationPort);
            this.Controls.Add(this.text_Box_Packet_Source_IP_Address);
            this.Controls.Add(this.labelPacketSourceIPAddress);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form4";
            this.Text = "Packet | Data";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelPacketSourceIPAddress;
        private System.Windows.Forms.TextBox text_Box_Packet_Source_IP_Address;
        private System.Windows.Forms.Label labelPacketDestinationPort;
        private System.Windows.Forms.TextBox text_Box_Packet_Destination_Port;
        private System.Windows.Forms.Label labelPacketDestinationIPAddress;
        private System.Windows.Forms.TextBox text_Box_Packet_Destination_IP_Address;
        private System.Windows.Forms.Label labelPacketSourcePort;
        private System.Windows.Forms.TextBox text_Box_Packet_Source_Port;
        private System.Windows.Forms.Label labelPacketProtocol;
        private System.Windows.Forms.TextBox text_Box_Packet_Protocol;
        private System.Windows.Forms.Label labelPacketData;
        private System.Windows.Forms.Button button_Packet_clear;
        private System.Windows.Forms.TextBox text_Box_Packet_Data;
        private System.Windows.Forms.Label label_packet_data;
        private System.Windows.Forms.Button button_Check_packet;
    }
}