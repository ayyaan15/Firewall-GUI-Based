﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static WindowsFormsApp1.Form2;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {

        
      // passing the Form2.Rule references 
        private List<Form2.Rule> rules; 
        private List<Packet> packets = new List<Packet>();


        public Form4(List<Form2.Rule>rules)
        {
            InitializeComponent();
            this.rules = rules;

        }
     
        public class Packet
        {
            public string Source_IPAddress { get; set; }
            public string Destination_IPAddress { get; set; }
            public int Source_Port { get; set; }
            public int Destination_Port { get; set; }
            public string Protocol { get; set; }
            public string Data { get; set; }
            public DateTime Time_stamp { get; set; }
            public bool IsMatch(Form2.Rule rule)
            {
                return rule.IsIPMatchPublic(rule.Source_IPAddress, Source_IPAddress) &&
                       rule.IsIPMatchPublic(rule.Destination_IPAddress, Destination_IPAddress) &&
                       rule.Source_Port == Source_Port &&
                       rule.Destination_Port == Destination_Port &&
                       Protocol.Equals(rule.Protocol, StringComparison.OrdinalIgnoreCase) &&
                       (rule.Data == null || rule.Data.Equals(Data, StringComparison.OrdinalIgnoreCase));
            }
        }


        private bool ValidatePacketData()
        {
            if (string.IsNullOrWhiteSpace(text_Box_Packet_Source_IP_Address.Text) ||
                string.IsNullOrWhiteSpace(text_Box_Packet_Destination_IP_Address.Text) ||
                string.IsNullOrWhiteSpace(text_Box_Packet_Protocol.Text) ||
                string.IsNullOrWhiteSpace(text_Box_Packet_Source_Port.Text) ||
                string.IsNullOrWhiteSpace(text_Box_Packet_Destination_Port.Text))
            {
                MessageBox.Show("Please enter all required packet data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!IsValidIPAddress(text_Box_Packet_Source_IP_Address.Text) ||
                !IsValidIPAddress(text_Box_Packet_Destination_IP_Address.Text))
            {
                MessageBox.Show("Please enter valid IP addresses.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!int.TryParse(text_Box_Packet_Source_Port.Text, out int sourcePort) ||
                !int.TryParse(text_Box_Packet_Destination_Port.Text, out int destinationPort) ||
                !IsValidPort(sourcePort) || !IsValidPort(destinationPort))
            {
                MessageBox.Show("Please enter valid port numbers (1-65535).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBoxProtocol_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxSourceIPAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxDestinationIPAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void labelSourcePort_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSourcePort_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxDestinationPort_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelProtocol_Click(object sender, EventArgs e)
        {

        }

        private void textBoxData_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ClearFormFields()
        {
            text_Box_Packet_Source_IP_Address.Clear();
            text_Box_Packet_Destination_IP_Address.Clear();
            text_Box_Packet_Source_Port.Clear();
            text_Box_Packet_Destination_Port.Clear();
            text_Box_Packet_Protocol.Clear();
            text_Box_Packet_Data.Clear();

        }
        private void button_Packet_save_Click(object sender, EventArgs e)
        {
            // Clear the text boxes
            ClearFormFields();
                
         }
        
        private bool IsValidIPAddress(string ipAddress)
        {
            return IPAddress.TryParse(ipAddress, out _);
        }

        private bool IsValidPort(int port)
        {
            return port >= 1 && port <= 65535;
        }

        private void label_packet_data_Click(object sender, EventArgs e)
        {

        }

        private void button_Check_packet_Click(object sender, EventArgs e)
        {
            Packet packet = CreatePacketFromFormData();

            if (packet == null)
            {
                return;
            }

            bool matchFound = false;
            foreach (var rule in rules)
            {
                if (packet.IsMatch(rule))
                {
                    string result = $"SRC_IP: {packet.Source_IPAddress}, DST_IP: {packet.Destination_IPAddress}, SRC_PORT: {packet.Source_Port}, DST_PORT: {packet.Destination_Port}, DATA: {packet.Data}, ACTION: {rule.Action}, RULE_NUMBER: {rule.RuleNumber}";
                    MessageBox.Show(result, "Match Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    matchFound = true;
                    break;
                }
            }

            if (!matchFound)
            {
                MessageBox.Show("No matching rule found for this packet.", "No Match", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private bool ValidatePacketData(Packet packet)
        {
            if (string.IsNullOrWhiteSpace(packet.Source_IPAddress) ||
                string.IsNullOrWhiteSpace(packet.Destination_IPAddress) ||
                string.IsNullOrWhiteSpace(packet.Protocol) ||
                packet.Source_Port <= 0 ||
                packet.Destination_Port <= 0)
            {
                MessageBox.Show("Please enter all required packet data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!IsValidIPAddress(packet.Source_IPAddress) ||
                !IsValidIPAddress(packet.Destination_IPAddress))
            {
                MessageBox.Show("Please enter valid IP addresses.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!IsValidPort(packet.Source_Port) || !IsValidPort(packet.Destination_Port))
            {
                MessageBox.Show("Please enter valid port numbers (1-65535).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        private Packet CreatePacketFromFormData()
        {
            int sourcePort = 0;
            int destinationPort = 0;

            if (int.TryParse(text_Box_Packet_Source_Port.Text, out sourcePort) &&
                int.TryParse(text_Box_Packet_Destination_Port.Text, out destinationPort))
            {
                return new Packet
                {
                    Source_IPAddress = text_Box_Packet_Source_IP_Address.Text,
                    Destination_IPAddress = text_Box_Packet_Destination_IP_Address.Text,
                    Source_Port = sourcePort,
                    Destination_Port = destinationPort,
                    Protocol = text_Box_Packet_Protocol.Text,
                    Data = text_Box_Packet_Data.Text,
                    Time_stamp = DateTime.Now
                };
            }
            else
            {
                MessageBox.Show("Please enter valid port numbers (1-65535).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

    }
}





