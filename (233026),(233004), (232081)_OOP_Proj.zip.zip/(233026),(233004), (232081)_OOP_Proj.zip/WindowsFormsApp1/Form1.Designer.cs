﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.btnHelp = new System.Windows.Forms.Button();
            this.panelHelpSubmenu = new System.Windows.Forms.Panel();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnformHelp = new System.Windows.Forms.Button();
            this.panelMoresubMenu = new System.Windows.Forms.Panel();
            this.btnTutorial = new System.Windows.Forms.Button();
            this.btnmore = new System.Windows.Forms.Button();
            this.panelHomesubmenu = new System.Windows.Forms.Panel();
            this.btnCheckPacket = new System.Windows.Forms.Button();
            this.btnPacketData = new System.Windows.Forms.Button();
            this.btnRules = new System.Windows.Forms.Button();
            this.Btnhome = new System.Windows.Forms.Button();
            this.Panel1logo = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelWelcome = new System.Windows.Forms.Panel();
            this.textBoxWelcome = new System.Windows.Forms.TextBox();
            this.panelChildform = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.panelSideMenu.SuspendLayout();
            this.panelHelpSubmenu.SuspendLayout();
            this.panelMoresubMenu.SuspendLayout();
            this.panelHomesubmenu.SuspendLayout();
            this.Panel1logo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelWelcome.SuspendLayout();
            this.panelChildform.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.AutoScroll = true;
            this.panelSideMenu.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelSideMenu.Controls.Add(this.btnHelp);
            this.panelSideMenu.Controls.Add(this.panelHelpSubmenu);
            this.panelSideMenu.Controls.Add(this.panelMoresubMenu);
            this.panelSideMenu.Controls.Add(this.btnmore);
            this.panelSideMenu.Controls.Add(this.panelHomesubmenu);
            this.panelSideMenu.Controls.Add(this.Btnhome);
            this.panelSideMenu.Controls.Add(this.Panel1logo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(200, 693);
            this.panelSideMenu.TabIndex = 0;
            // 
            // btnHelp
            // 
            this.btnHelp.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnHelp.FlatAppearance.BorderSize = 0;
            this.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHelp.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnHelp.Location = new System.Drawing.Point(0, 497);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(200, 43);
            this.btnHelp.TabIndex = 6;
            this.btnHelp.Text = " FIreWall | Help";
            this.btnHelp.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnHelp.UseVisualStyleBackColor = false;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // panelHelpSubmenu
            // 
            this.panelHelpSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(35)))), ((int)(((byte)(39)))));
            this.panelHelpSubmenu.Controls.Add(this.btnAbout);
            this.panelHelpSubmenu.Controls.Add(this.btnformHelp);
            this.panelHelpSubmenu.Location = new System.Drawing.Point(0, 543);
            this.panelHelpSubmenu.Name = "panelHelpSubmenu";
            this.panelHelpSubmenu.Size = new System.Drawing.Size(200, 132);
            this.panelHelpSubmenu.TabIndex = 1;
            // 
            // btnAbout
            // 
            this.btnAbout.BackColor = System.Drawing.Color.SlateGray;
            this.btnAbout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbout.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnAbout.Location = new System.Drawing.Point(0, 43);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(200, 43);
            this.btnAbout.TabIndex = 8;
            this.btnAbout.Text = "About";
            this.btnAbout.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnAbout.UseVisualStyleBackColor = false;
            this.btnAbout.Click += new System.EventHandler(this.button10_Click);
            // 
            // btnformHelp
            // 
            this.btnformHelp.BackColor = System.Drawing.Color.SlateGray;
            this.btnformHelp.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnformHelp.FlatAppearance.BorderSize = 0;
            this.btnformHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnformHelp.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnformHelp.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnformHelp.Location = new System.Drawing.Point(0, 0);
            this.btnformHelp.Name = "btnformHelp";
            this.btnformHelp.Size = new System.Drawing.Size(200, 43);
            this.btnformHelp.TabIndex = 7;
            this.btnformHelp.Text = "Help";
            this.btnformHelp.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnformHelp.UseVisualStyleBackColor = false;
            this.btnformHelp.Click += new System.EventHandler(this.button9_Click);
            // 
            // panelMoresubMenu
            // 
            this.panelMoresubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(35)))), ((int)(((byte)(39)))));
            this.panelMoresubMenu.Controls.Add(this.btnTutorial);
            this.panelMoresubMenu.Location = new System.Drawing.Point(0, 385);
            this.panelMoresubMenu.Name = "panelMoresubMenu";
            this.panelMoresubMenu.Size = new System.Drawing.Size(200, 43);
            this.panelMoresubMenu.TabIndex = 5;
            // 
            // btnTutorial
            // 
            this.btnTutorial.BackColor = System.Drawing.Color.SlateGray;
            this.btnTutorial.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTutorial.FlatAppearance.BorderSize = 0;
            this.btnTutorial.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTutorial.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTutorial.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnTutorial.Location = new System.Drawing.Point(0, 0);
            this.btnTutorial.Name = "btnTutorial";
            this.btnTutorial.Size = new System.Drawing.Size(200, 41);
            this.btnTutorial.TabIndex = 7;
            this.btnTutorial.Text = "Tutorial";
            this.btnTutorial.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnTutorial.UseVisualStyleBackColor = false;
            this.btnTutorial.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnmore
            // 
            this.btnmore.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnmore.FlatAppearance.BorderSize = 0;
            this.btnmore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnmore.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmore.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnmore.Location = new System.Drawing.Point(0, 345);
            this.btnmore.Name = "btnmore";
            this.btnmore.Size = new System.Drawing.Size(200, 43);
            this.btnmore.TabIndex = 4;
            this.btnmore.Text = " FireWall | More";
            this.btnmore.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnmore.UseVisualStyleBackColor = false;
            this.btnmore.Click += new System.EventHandler(this.btnmore_Click);
            // 
            // panelHomesubmenu
            // 
            this.panelHomesubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(35)))), ((int)(((byte)(39)))));
            this.panelHomesubmenu.Controls.Add(this.btnCheckPacket);
            this.panelHomesubmenu.Controls.Add(this.btnPacketData);
            this.panelHomesubmenu.Controls.Add(this.btnRules);
            this.panelHomesubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHomesubmenu.Location = new System.Drawing.Point(0, 158);
            this.panelHomesubmenu.Name = "panelHomesubmenu";
            this.panelHomesubmenu.Size = new System.Drawing.Size(200, 130);
            this.panelHomesubmenu.TabIndex = 3;
            // 
            // btnCheckPacket
            // 
            this.btnCheckPacket.BackColor = System.Drawing.Color.SlateGray;
            this.btnCheckPacket.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCheckPacket.FlatAppearance.BorderSize = 0;
            this.btnCheckPacket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCheckPacket.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckPacket.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnCheckPacket.Location = new System.Drawing.Point(0, 86);
            this.btnCheckPacket.Name = "btnCheckPacket";
            this.btnCheckPacket.Size = new System.Drawing.Size(200, 43);
            this.btnCheckPacket.TabIndex = 5;
            this.btnCheckPacket.Text = "View | Rules";
            this.btnCheckPacket.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnCheckPacket.UseVisualStyleBackColor = false;
            this.btnCheckPacket.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnPacketData
            // 
            this.btnPacketData.BackColor = System.Drawing.Color.SlateGray;
            this.btnPacketData.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPacketData.FlatAppearance.BorderSize = 0;
            this.btnPacketData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPacketData.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPacketData.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnPacketData.Location = new System.Drawing.Point(0, 43);
            this.btnPacketData.Name = "btnPacketData";
            this.btnPacketData.Size = new System.Drawing.Size(200, 43);
            this.btnPacketData.TabIndex = 4;
            this.btnPacketData.Text = "Enter | Packet Data";
            this.btnPacketData.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPacketData.UseVisualStyleBackColor = false;
            this.btnPacketData.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnRules
            // 
            this.btnRules.BackColor = System.Drawing.Color.SlateGray;
            this.btnRules.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRules.FlatAppearance.BorderSize = 0;
            this.btnRules.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRules.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRules.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnRules.Location = new System.Drawing.Point(0, 0);
            this.btnRules.Name = "btnRules";
            this.btnRules.Size = new System.Drawing.Size(200, 43);
            this.btnRules.TabIndex = 3;
            this.btnRules.Text = "Enter | Rules";
            this.btnRules.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnRules.UseVisualStyleBackColor = false;
            this.btnRules.Click += new System.EventHandler(this.button2_Click);
            // 
            // Btnhome
            // 
            this.Btnhome.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btnhome.Dock = System.Windows.Forms.DockStyle.Top;
            this.Btnhome.FlatAppearance.BorderSize = 0;
            this.Btnhome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btnhome.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnhome.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Btnhome.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Btnhome.Location = new System.Drawing.Point(0, 108);
            this.Btnhome.Name = "Btnhome";
            this.Btnhome.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Btnhome.Size = new System.Drawing.Size(200, 50);
            this.Btnhome.TabIndex = 2;
            this.Btnhome.Text = "FireWall | Home";
            this.Btnhome.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Btnhome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btnhome.UseVisualStyleBackColor = false;
            this.Btnhome.Click += new System.EventHandler(this.button1_Click);
            // 
            // Panel1logo
            // 
            this.Panel1logo.Controls.Add(this.pictureBox2);
            this.Panel1logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel1logo.Location = new System.Drawing.Point(0, 0);
            this.Panel1logo.Name = "Panel1logo";
            this.Panel1logo.Size = new System.Drawing.Size(200, 108);
            this.Panel1logo.TabIndex = 1;
            this.Panel1logo.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApp1.Properties.Resources._9350471_managed_firewall1;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(194, 105);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panelWelcome
            // 
            this.panelWelcome.AutoScroll = true;
            this.panelWelcome.AutoSize = true;
            this.panelWelcome.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelWelcome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panelWelcome.Controls.Add(this.textBoxWelcome);
            this.panelWelcome.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelWelcome.Location = new System.Drawing.Point(200, 601);
            this.panelWelcome.Name = "panelWelcome";
            this.panelWelcome.Size = new System.Drawing.Size(812, 92);
            this.panelWelcome.TabIndex = 1;
            // 
            // textBoxWelcome
            // 
            this.textBoxWelcome.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBoxWelcome.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBoxWelcome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.textBoxWelcome.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxWelcome.Font = new System.Drawing.Font("Algerian", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxWelcome.ForeColor = System.Drawing.Color.Firebrick;
            this.textBoxWelcome.Location = new System.Drawing.Point(124, 8);
            this.textBoxWelcome.Multiline = true;
            this.textBoxWelcome.Name = "textBoxWelcome";
            this.textBoxWelcome.Size = new System.Drawing.Size(591, 81);
            this.textBoxWelcome.TabIndex = 1;
            this.textBoxWelcome.Text = "WelCome | FireWall";
            this.textBoxWelcome.TextChanged += new System.EventHandler(this.textBoxWelcome_TextChanged);
            // 
            // panelChildform
            // 
            this.panelChildform.AutoScroll = true;
            this.panelChildform.AutoSize = true;
            this.panelChildform.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panelChildform.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panelChildform.Controls.Add(this.pictureBox1);
            this.panelChildform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildform.Location = new System.Drawing.Point(200, 0);
            this.panelChildform.Name = "panelChildform";
            this.panelChildform.Size = new System.Drawing.Size(812, 601);
            this.panelChildform.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources._9350471_managed_firewall;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(812, 601);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1012, 693);
            this.Controls.Add(this.panelChildform);
            this.Controls.Add(this.panelWelcome);
            this.Controls.Add(this.panelSideMenu);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelHelpSubmenu.ResumeLayout(false);
            this.panelMoresubMenu.ResumeLayout(false);
            this.panelHomesubmenu.ResumeLayout(false);
            this.Panel1logo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelWelcome.ResumeLayout(false);
            this.panelWelcome.PerformLayout();
            this.panelChildform.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.FlowLayoutPanel Panel1logo;
        private System.Windows.Forms.Panel panelHomesubmenu;
        private System.Windows.Forms.Button Btnhome;
        private System.Windows.Forms.Button btnCheckPacket;
        private System.Windows.Forms.Button btnPacketData;
        private System.Windows.Forms.Button btnRules;
        private System.Windows.Forms.Panel panelHelpSubmenu;
        private System.Windows.Forms.Panel panelMoresubMenu;
        private System.Windows.Forms.Button btnTutorial;
        private System.Windows.Forms.Button btnmore;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Button btnformHelp;
        private System.Windows.Forms.Panel panelWelcome;
        private System.Windows.Forms.Panel panelChildform;
        private System.Windows.Forms.TextBox textBoxWelcome;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
    }
}

