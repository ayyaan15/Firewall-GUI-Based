﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormsApp1.Form2;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        
        private List<Form2.Rule> rules = new List<Form2.Rule>();
       
        public Form1()
        {
            InitializeComponent();
            CustomizeDesign();

        }
        private void CustomizeDesign()
        {
            panelHomesubmenu.Visible = false;
            panelMoresubMenu.Visible = false;
            panelHelpSubmenu.Visible = false;
        }

        private void HideSubMenu()
        {
            if (panelHomesubmenu.Visible == true) 
            panelHomesubmenu.Visible = false;

            if (panelMoresubMenu.Visible == true) 
                panelMoresubMenu.Visible = false;

            if (panelHelpSubmenu.Visible == true)
                panelHelpSubmenu.Visible = false;

                
            
        }
        private void ShowSubMenu(Panel subMenu) {
            if(subMenu.Visible == false)
            {
                HideSubMenu();
                subMenu.Visible = true;
            }
            else 
                subMenu.Visible = false;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            ShowSubMenu(panelHomesubmenu);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            // this will hide the submenu panel
            HideSubMenu();
            
            // this button named enter|rules will open the formm to enter the rules
            openChildForm(new Form2(rules));
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // this will hide the submenu panel
            HideSubMenu();
            // this open the child form when the button packet | data is clicked 
            openChildForm(new Form4(rules));

        }
       

        private void button4_Click(object sender, EventArgs e)
        {
            // this is the hide method
            HideSubMenu();

            // this button named check packet  will  open the formm to enter the rules
            openChildForm(new Form5(rules));
           
        }
      

        private void btnmore_Click(object sender, EventArgs e)
        {
            ShowSubMenu(panelMoresubMenu);
        }

        private void button6_Click(object sender, EventArgs e)
        {   
            // this is the hide method
            HideSubMenu();

            // when the  we clcik more and in more Generate|report button open the form

            openChildForm(new Form3());
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // this is the hide method
            HideSubMenu();
            // when the  we clcik more and in more  button  Tutorial open the  form tutorial

        openChildForm(new Form6());
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            ShowSubMenu(panelHelpSubmenu);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            // this is the hide method
            HideSubMenu();
            // when   we clcik Help and in  button  help open the  form help
            openChildForm(new Form8());

        }

        private void button10_Click(object sender, EventArgs e)
        {
            // this is the hide method
            HideSubMenu();
            // when the  we clcik Help and in  button  about open the  form about
            openChildForm(new Form7());
        }
        private Form activeForm = null;
        private void openChildForm(Form childForm)
        {
            if (activeForm != null) 
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.  FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildform.Controls.Add(childForm);
            panelChildform.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private async void textBoxWelcome_TextChanged(object sender, EventArgs e)
        {
            textBoxWelcome.Text = "";
            string message = "Welcome | Firewall";
            foreach (char c in message)
            {
                textBoxWelcome.Text += c;
                await Task.Delay(100); // Wait for 500 milliseconds
            }
        }

        private void pictureBox3_panelogo_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
